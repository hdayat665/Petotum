<!DOCTYPE html>
<html lang="en">
<head>
  <title>Petotum</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
td{
  text-align: center;
  font-size: 20px;
  color: white;
  background-color: grey;
  padding-top: 7% !important;
  text-transform: uppercase;
}
</style>
<body>


<div class="container">
  <h2>How to use</h2>
  <p>Click on box that have text to edit position, color and style. <br> Box display number of position. <br> Select number in form management to change its position. <br> Box with text cannot be choose to be reposition.</p>            
  <table class="table table-bordered">
  
    <tbody>
      <tr>
        <!-- <?php echo $data[0]['pet_desc'] ?> -->
        <td data-toggle="modal" data-target="#myModal1" style="background-image:url(https://lh3.googleusercontent.com/proxy/G0zcOcN0_aWyCZs8Ps9IF2h59JaPIkrUaj41BjlYm9zqwaFdSVIjtrxz_5Rx6RNFtUnDi5M74oSs4hfxicn9KyqCO4MLUIXvVk2JmpIhKg);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px; font-weight: <?= $data[0]['pet_style'] ?> ;background-color: <?= $data[0]['pet_color'] ?>"><?= $data[0]['pet_desc'] ?></td>

        <td id="2" data-toggle="modal" data-target="#myModal2" style="background-image:url(https://i.ya-webdesign.com/images/number-2-png-7.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[1]['pet_style'] ?> ;background-color: <?= $data[1]['pet_color'] ?>"><?= $data[1]['pet_desc'] ?></td>

        <td id="3" data-toggle="modal" data-target="#myModal3" style="background-image:url(https://i.ya-webdesign.com/images/number-3-icon-png.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[2]['pet_style'] ?> ;background-color: <?= $data[2]['pet_color'] ?>"><?= $data[2]['pet_desc'] ?></td>

        <td id="4" data-toggle="modal" data-target="#myModal4" style="background-image:url(https://bustin.com/wp-content/uploads/2011/10/4NumberFourInCircle.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[3]['pet_style'] ?> ;background-color: <?= $data[3]['pet_color'] ?>"><?= $data[3]['pet_desc'] ?></td>
      </tr>
      <tr>
        <td id="5" data-toggle="modal" data-target="#myModal5" style="background-image:url(https://cdn.onlinewebfonts.com/svg/img_2199.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[4]['pet_style'] ?> ;background-color: <?= $data[4]['pet_color'] ?>"><?= $data[4]['pet_desc'] ?></td>

        <td id="6" data-toggle="modal" data-target="#myModal6" style="background-image:url(https://blog.flashissue.com/wp-content/uploads/2012/05/6NumberSixInCircle.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[5]['pet_style'] ?> ;background-color: <?= $data[5]['pet_color'] ?>"><?= $data[5]['pet_desc'] ?></td>

        <td id="7" data-toggle="modal" data-target="#myModal7" style="background-image:url(https://2.bp.blogspot.com/-YwkY83j536o/Tzs8yjw4GyI/AAAAAAAAAPI/SQk6v5eOlo0/s1600/7.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[6]['pet_style'] ?> ;background-color: <?= $data[6]['pet_color'] ?>"><?= $data[6]['pet_desc'] ?></td>

        <td id="8" data-toggle="modal" data-target="#myModal8" style="background-image:url(https://i.dlpng.com/static/png/6530644_preview.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[7]['pet_style'] ?> ;background-color: <?= $data[7]['pet_color'] ?>"><?= $data[7]['pet_desc'] ?></td>
      </tr>
      <tr>
        <td id="9" data-toggle="modal" data-target="#myModal9" style="background-image:url(https://cdn.onlinewebfonts.com/svg/img_2203.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[8]['pet_style'] ?> ;background-color: <?= $data[8]['pet_color'] ?>"><?= $data[8]['pet_desc'] ?></td>
        <td id="10" data-toggle="modal" data-target="#myModal10" style="background-image:url(https://directdigitalsolutions.com.au/wp-content/uploads/2014/01/ten_steps.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[9]['pet_style'] ?> ;background-color: <?= $data[9]['pet_color'] ?>"><?= $data[9]['pet_desc'] ?></td>
        <td id="11" data-toggle="modal" data-target="#myModal11" style="background-image:url(https://cdn.bleacherreport.net/images_root/slides/photos/000/426/977/11NumberElevenInCircle_original_original.png?1286319377);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[10]['pet_style'] ?> ;background-color: <?= $data[10]['pet_color'] ?>"><?= $data[10]['pet_desc'] ?></td>
        <td id="12" data-toggle="modal" data-target="#myModal12" style="background-image:url(https://s3.amazonaws.com/tinycards/image/88a8de1e1ae2f34522d881a8bd3e1bc9);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[11]['pet_style'] ?> ;background-color: <?= $data[11]['pet_color'] ?>"><?= $data[11]['pet_desc'] ?></td>
      </tr>
       <tr>
        <td id="13" data-toggle="modal" data-target="#myModal13" style="background-image:url(https://simonleung.com/wp-content/uploads/2017/04/lucky_unlucky_13.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[12]['pet_style'] ?> ;background-color: <?= $data[12]['pet_color'] ?>"><?= $data[12]['pet_desc'] ?></td>
        <td id="14" data-toggle="modal" data-target="#myModal14" style="background-image:url(https://upload.wikimedia.org/wikipedia/commons/9/99/14NumberFourteenInCircle.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[13]['pet_style'] ?> ;background-color: <?= $data[13]['pet_color'] ?>"><?= $data[13]['pet_desc'] ?></td>
        <td id="15" data-toggle="modal" data-target="#myModal15" style="background-image:url(https://pluspng.com/img-png/number-fifteen-png-15-clipart-500.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[14]['pet_style'] ?> ;background-color: <?= $data[14]['pet_color'] ?>"><?= $data[14]['pet_desc'] ?></td>
        <td id="16" data-toggle="modal" data-target="#myModal16" style="background-image:url(https://upload.wikimedia.org/wikipedia/commons/e/e5/16NumberSixteenInCircle.png);background-repeat:no-repeat;background-size:250px 180px;   width: 250px; height: 180px;font-weight: <?= $data[15]['pet_style'] ?> ;background-color: <?= $data[15]['pet_color'] ?>"><?= $data[15]['pet_desc'] ?></td>
      </tr>
    </tbody>
  </table>
</div>
 <?php
  foreach ($data as $key) {?>
    
  <div class="modal fade" id="myModal<?= $key['id'] ?>" role="dialog">
    <div class="modal-dialog">
    
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Management</h4>
        </div>
        <div class="modal-body">
          <form action="Home/data_submitted" method="post">
            <span>Text Position</span>
            <?php
            $options = lkp_position(); 
            // pr($options);
            $data1 = $key['pet_row'];
            echo form_dropdown('position', $options, $data1, "class='form-control form-control-user' required" );
            ?><br>
            
            <span>Color</span>
             <?php
            $options = lkp_color(); 
            // pr($options);
            $data2 = $key['pet_color'];
            // pr($data);
            echo form_dropdown('color', $options, $data2, "class='form-control form-control-user'");
            ?><br>
            
            <span>Font Style Bold</span>
             <?php
            $options = lkp_style(); 
            // pr($options);
            $data3 = $key['pet_style'];
            echo form_dropdown('style', $options, $data3, "class='form-control form-control-user'");
            ?><br>
            <input type="hidden" name="pet_desc" value="<?= $key['pet_desc'] ?>">
            <input type="hidden" name="id" value="<?= $key['id'] ?>">

            <button type="submit" class="btn btn-primary">Save</button>
            
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  <?php } ?>

</body>
</html>
