<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home_model extends CI_Model {

	function __construct(){
		$this->load->database();
	}

	function data()
	{

		$sql = "SELECT * FROM petotum";

		$result = $this->db->query($sql)->result_array();

		return $result;

	}

	function data_update($data)
	{
		// pr($data['style']);
		$style = $data['style'];
		$desc = $data['pet_desc'];
		$position = $data['position'];
		$color = $data['color'];
		$id_before = $data['id'];
		$id_after = $data['position'];

		// $sql = "UPDATE petotum set pet_style = '$style', pet_desc = '$desc', pet_color = '$color' where id = $id_after";

		$this->db->set('pet_style' , $style);
		$this->db->set('pet_desc' , $desc);
		$this->db->set('pet_color' , $color);
		$this->db->where('id', $id_after);
		$result1 = $this->db->update('petotum');

		if ($id_before != $id_after) {
			
			$this->db->set('pet_style' , '');
			$this->db->set('pet_desc' , '');
			$this->db->set('pet_color' , '');
			$this->db->where('id', $id_before);
			$result2 = $this->db->update('petotum');
		}

		$result = 'not ok';

		if ($result1) {
			$result = 'OK';
		}

		return $result;
	}

}