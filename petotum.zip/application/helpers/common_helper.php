<?php 

if ( ! function_exists('pr'))
{
    function pr ( $dump = array(), $exit = true )
    {
        // $CI =& get_instance();
        // $CI->load->library('kint');
        // Kint::trace();

        echo "<pre>"; 
        print_r( $dump );
        echo "</pre>";
        
        if ($exit) exit;
    }
}

 if ( ! function_exists( "lkp_position" ))
{
    function lkp_position()
    {
        
    $CI =& get_instance();

     $CI->db->where('pet_desc', '');

     $query1 =  $CI->db->get('petotum');

     $query = $query1->result_array();

     $job_position2[''] = _(' Please Select'); 
     foreach($query as $r) { 
        $job_position2[$r['id']] = $r['id']; 
    } 
    return $job_position2;
    }
}

if ( ! function_exists( "lkp_color" ))
{
    function lkp_color()
    {
    $job_position2 = array(
        '' => 'Please Select',
        'Blue' => 'Blue',
        'Red' => 'Red',
        'Green' => 'Green'
    
    );

    return $job_position2;
    }
}

if ( ! function_exists( "lkp_style" ))
{
    function lkp_style()
    {
    $job_position2 = array(
        '' => 'Please Select',
        'Bold' => 'Bold',
        'Normal' => 'Normal'
    
    );

    return $job_position2;
    }
}