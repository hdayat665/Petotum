-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2020 at 07:02 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `petotum`
--

-- --------------------------------------------------------

--
-- Table structure for table `petotum`
--

CREATE TABLE `petotum` (
  `id` int(255) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `pet_desc` varchar(255) NOT NULL,
  `pet_row` int(11) NOT NULL,
  `pet_color` varchar(255) NOT NULL,
  `pet_style` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `petotum`
--

INSERT INTO `petotum` (`id`, `pet_id`, `pet_desc`, `pet_row`, `pet_color`, `pet_style`) VALUES
(1, 1, '', 1, '', ''),
(2, 2, 'petotum.com', 2, '', 'Normal'),
(3, 3, '', 3, '', ''),
(4, 4, 'Build Trust', 4, '', 'Normal'),
(5, 5, '', 5, '', '0'),
(6, 6, '', 6, '', '0'),
(7, 7, 'Pet care dashboard', 7, '', 'Normal'),
(8, 8, '', 8, '', '0'),
(9, 9, 'Pet parent dashboard', 9, '', 'Normal'),
(10, 10, '', 10, '', ''),
(11, 11, '', 11, '', ''),
(12, 12, '', 12, '', ''),
(13, 13, '', 13, '', '0'),
(14, 14, '', 14, '', ''),
(15, 15, '', 15, '', ''),
(16, 16, 'Provide Transparency', 16, '', 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `position`
--

CREATE TABLE `position` (
  `id` int(11) NOT NULL,
  `pos_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `position`
--

INSERT INTO `position` (`id`, `pos_id`, `status`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 0),
(6, 6, 0),
(7, 7, 0),
(8, 8, 0),
(9, 9, 0),
(10, 10, 0),
(11, 11, 0),
(12, 12, 1),
(13, 13, 0),
(14, 14, 0),
(15, 15, 0),
(16, 16, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `petotum`
--
ALTER TABLE `petotum`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `position`
--
ALTER TABLE `position`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `petotum`
--
ALTER TABLE `petotum`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `position`
--
ALTER TABLE `position`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
